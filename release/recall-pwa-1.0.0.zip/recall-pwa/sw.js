/* Recall service worker — generated at build time from src/sw-template.js.
 * Precaches every file of the build so the app, all bundled passages and all
 * assets work offline after the first successful load. Same-origin only: it
 * never touches requests to other sites (there are none by design).
 */
const CACHE_VERSION = 'd1981640c7b6b19a';
const CACHE = 'recall-' + CACHE_VERSION;
const PRECACHE = [
  "./",
  "./assets/backup-D64spGm3.js",
  "./assets/index-5UVphGMV.css",
  "./assets/index-DU81n3Wb.js",
  "./icons/apple-touch-icon.png",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./icons/icon-maskable-512.png",
  "./icons/icon.svg",
  "./icons/maskable.svg",
  "./index.html",
  "./manifest.webmanifest"
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(CACHE)
      .then((cache) => cache.addAll(PRECACHE.map((p) => new Request(p, { cache: 'reload' }))))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys.filter((k) => k.startsWith('recall-') && k !== CACHE).map((k) => caches.delete(k)),
        ),
      )
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('message', (event) => {
  if (event.data === 'recall:version' && event.source)
    event.source.postMessage({ type: 'recall:version', version: CACHE_VERSION });
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  if (req.mode === 'navigate') {
    // Network first so updates arrive; fall back to the cached app shell when offline.
    event.respondWith(
      fetch(req)
        .then((res) => {
          if (res.ok) {
            const copy = res.clone();
            caches
              .open(CACHE)
              .then((c) => c.put(new URL('./index.html', self.registration.scope).href, copy));
          }
          return res;
        })
        .catch(() =>
          caches
            .match(new URL('./index.html', self.registration.scope).href, {
              ignoreSearch: true,
              ignoreVary: true,
            })
            .then(
              (r) =>
                r ||
                caches.match(new URL('./', self.registration.scope).href, { ignoreVary: true }),
            ),
        ),
    );
    return;
  }

  // Static assets: cache first (they are content-hashed), then network.
  event.respondWith(
    caches.match(req, { ignoreSearch: true, ignoreVary: true }).then(
      (cached) =>
        cached ||
        fetch(req).then((res) => {
          if (res.ok && res.type === 'basic') {
            const copy = res.clone();
            caches.open(CACHE).then((c) => c.put(req, copy));
          }
          return res;
        }),
    ),
  );
});
